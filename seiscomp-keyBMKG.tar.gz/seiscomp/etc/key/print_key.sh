#!/bin/bash
ls | grep station_IA >> list_all
a=($(cat list_all))
for i in ${a[*]}; do
echo "# Binding references" >> $i
echo "global:HN" >> $i
echo "seedlink:212" >> $i
echo "slarchive:BMKG" >> $i
#echo "slmon:simora" >> $i
done
rm list_all
