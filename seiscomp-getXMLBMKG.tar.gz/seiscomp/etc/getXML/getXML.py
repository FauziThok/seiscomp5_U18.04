#!/usr/bin/env python3

import requests
import pandas as pd
from datetime import datetime
import os
import shutil

#input
ipAddress = input("FDSNWS IP Address [202.90.199.206] : ")
latRef = input("Reference Lat (deg) [2.943] : ")
lonRef = input("Reference Lon (deg) [98.067] : ")
radCir = input("Radius Circle (km) [500] : ")
radCir = str(int(radCir)/111.317)
now = datetime.now()
dtDate = now.strftime("%Y-%m-%d")

#create simple url to get list sta
urlSmpl = 'http://'+ipAddress+':8080/fdsnws/station/1/query?starttime='+dtDate+'T00%3A00%3A00&endtime='+dtDate+'T00%3A00%3A00&station=*&channel=*Z&latitude='+latRef+'&longitude='+lonRef+'&maxradius='+radCir+'&level=channel&format=text'

#add dataframe from url
dfSta = pd.read_csv(urlSmpl, sep = '|')

#remove duplicate sensor on column Station
dfSta.drop_duplicates(subset=['Station'])

#create directory
shutil.rmtree("inventory")
os.mkdir("inventory")
os.chdir("inventory")

#download xml
for sta in dfSta['Station']:
	urlFnl = 'http://'+ipAddress+':8080/fdsnws/station/1/query?starttime='+dtDate+'T00%3A00%3A00&endtime='+dtDate+'T00%3A00%3A00&station='+sta+'&latitude='+latRef+'&longitude='+lonRef+'&maxradius='+radCir+'&level=response&format=sc3ml'
	#print(urlFnl)
	print('downloading XML for '+sta)
	response = requests.get(urlFnl)
	with open(sta+'.xml', 'wb') as file:
		file.write(response.content)

#elim palert
for sta in dfSta['Station']:
	with open(sta+'.xml','r') as text_file:
		lines = text_file.readlines()
		for line in lines:
			if "Palert" in line:
				#print(sta)
				os.remove(sta+'.xml')
				print('deleting '+sta+'.xml (Palert)')
				dfSta = dfSta.drop(dfSta[dfSta['Station'] == sta].index)

dfSta.to_csv('listStation', encoding='utf-8')
print('completed')

